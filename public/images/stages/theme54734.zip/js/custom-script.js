(function($) {
	$(function(){
		//Dropdown cart in header
		$('.cart-holder > h3').click(function(){
			if($(this).hasClass('cart-opened')) {
				$(this).removeClass('cart-opened').next().slideUp(300);
			} else {
				$(this).addClass('cart-opened').next().slideDown(300);
			}
		});

		//Popup rating content
		$('.star-rating').each(function(){
			rate_cont = $(this).attr('title');
			$(this).append('<b class="rate_content">' + rate_cont + '</b>');
		});

		//Disable cart selection
		(function ($) {
			$.fn.disableSelection = function () {
				return this
					.attr('unselectable', 'on')
					.css('user-select', 'none')
					.on('selectstart', false);
			};
			$('.cart-holder h3').disableSelection();
		})(jQuery);

		//Fix contact form not valid messages errors
		jQuery(window).load(function() {
			jQuery('.wpcf7-not-valid-tip').live('mouseover', function(){
				jQuery(this).fadeOut();
			});

			jQuery('.wpcf7-form input[type="reset"]').live('click', function(){
				jQuery('.wpcf7-not-valid-tip, .wpcf7-response-output').fadeOut();
			});
		});

		// compare trigger
		$(document).on('click', '.cherry-compare', function(event) {
			event.preventDefault();
			button = $(this);
			$('body').trigger( 'yith_woocompare_open_popup', { response: compare_data.table_url, button: button } )
		});

		// Span wrapper
		$('li.product').find('.compare, .add_to_wishlist, .add_to_cart_button, .btn').wrapInner('<span class="feedback"><span />');

		// Onsale wrapper
		$('.cherry-thumb-wrap').find('.onsale').wrapInner('<span class="onsale_wrap">');
		$('.content-holder').find('.onsale').wrapInner('<span class="onsale_wrap">');

		// clone wrapp
			$('.products .product').each(function(){
				_this = $(this);
				_this.find('.price > ins').after(_this.find('.price > del'));
				var thisButtonsBlock = $('<div class="buttonsBlock"></div>');
				_this.append(thisButtonsBlock);
				var buttons = _this.find('.add_to_cart_button, .product-list-buttons, li > .btn, li > a .cherry-quick-view');
				thisButtonsBlock.append(buttons);
				_this.find('.product-list-buttons').after(_this.find('.cherry-quick-view'));
				_this.find('.buttonsBlock').after(_this.find('.star-rating'));
			});

			$('.product-list-buttons').each(function(){
				_this = $(this);
				_this.find('.compare').after(_this.find('.yith-wcwl-add-to-wishlist'));
			});

			$('.products .product').each(function(){
				_this = $(this);
				var thisButtonsBlock = $('<div class="buttons-block-wrapper"></div>');
				_this.append(thisButtonsBlock);
				var buttons = _this.find('.buttonsBlock, .star-rating, .short_desc');
				thisButtonsBlock.append(buttons);

				// Clone
				var prodCopy = _this.clone();
				$(_this).append('<div class="product_hidden-content"></div>');
				$('.product_hidden-content', _this).append(prodCopy);
			});


			//click for search
			jQuery(document).ready(function() {
				jQuery('.header .search_button').click(function(){
					if ($("#search-header").is(":visible")) {
						$("#search-header").removeClass('search-opened').fadeOut(200);
					} else {
						$("#search-header").addClass('search-opened').fadeIn(200).find('.search-form_it').focus();
					};
				})
			});


		// If an event gets to the body
		$("html, a.cherry-wc-account_title").click(function(event){
			$(".cart-holder h3").removeClass("cart-opened").next().slideUp(300);

			if ( event.target.className != 'search-form_it' && $("#search-header").is(":visible") ) {
				$("#search-header").fadeOut(200);
			}
		});

		// Prevent events from getting pass h3
		$(".cart-holder h3, .widget_shopping_cart_content, .header .search_button").click(function(e){
			var cherryWcAccountTitle = $('.cherry-wc-account_title');
			if (e.target == $('.header .search_button')[0]) {
				if ($('h3.cart-opened').length != 0) {
					$('h3.cart-opened').removeClass('cart-opened').next().slideUp(300);
				}
			}
			if (e.target == $('.cart-holder h3')[0] && $('#search-header.search-opened').length) {
				$("#search-header").removeClass('search-opened').fadeOut(200);
			}
			if (cherryWcAccountTitle.hasClass('cherry-dropdown-opened')) {
				cherryWcAccountTitle.removeClass('cherry-dropdown-opened');
				cherryWcAccountTitle.parent().find('.cherry-wc-account_content').slideUp(300).removeClass('opened');
				e.stopPropagation();
			} else {
				e.stopPropagation();
			}
		});

	});

})(jQuery);
