<?php
/**
 * Open wrapper temaplte for shop pages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
			</div>
		</div>
	</div>
</div>