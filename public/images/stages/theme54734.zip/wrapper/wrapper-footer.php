<?php /* Wrapper Name: Footer */ ?>
<div class="row footer-widgets">
	<div class="span3" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-1">
		<?php dynamic_sidebar("footer-sidebar-1"); ?>
	</div>
	<div class="span3" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-2">
		<?php dynamic_sidebar("footer-sidebar-2"); ?>
	</div>
	<div class="span3" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-3">
		<?php dynamic_sidebar("footer-sidebar-3"); ?>
	</div>
	<div class="span3" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-4">
		<?php dynamic_sidebar("footer-sidebar-4"); ?>
	</div>
</div>


<div class="row">
	<div class="span4">
		<?php get_template_part("static/static-footer-logo"); ?>
		<?php dynamic_sidebar( 'footer-text' ); ?>
		<?php get_template_part("static/static-social-networks"); ?>
	</div>
	<div class="span4">
		<?php dynamic_sidebar( 'facebook' ); ?>
	</div>
	<div class="span2">
		<?php get_template_part("static/static-footer-nav"); ?>
	</div>
	<div class="span2">
		<div class="footer-shop-nav">
			<?php wp_nav_menu( array(
			    'container'       => 'ul', 
			    'menu_class'      => 'shop-menu', 
			    'menu_id'         => 'shopnav',
			    'depth'           => 0,
			    'theme_location' => 'shop_menu'
			));?>
		</div>
	</div>
</div>

<div class="row">
	<div class="span12 copyright" data-motopress-type="static" data-motopress-static-file="static/static-footer-text.php">
		<?php get_template_part("static/static-footer-text"); ?>
	</div>
</div>